# pycnumanal
Python master program calling C numerical analysis routines
